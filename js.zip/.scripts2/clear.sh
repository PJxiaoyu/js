#git clone git@gitee.com:highdimen/jd_scripts.git
cd jd_scripts
git checkout --orphan latest_branch
git add -A
git commit --date="May 7 9:05:20 2020 +0800" -am "."
git branch -D master
git branch -m master
git push -f origin master
cd ../
#rm -rf jd_scripts

#git clone git@gitee.com:highdimen/jd_scripts.git
cd clone_scripts
git add .
git commit -m "$TIME"
git push
cd ../
#rm -rf jd_scripts


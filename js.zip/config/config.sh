## Version: v3.12.0
## Date: 2021-06-19
## Update Content: 领现金兑换红包接口（选填） 6-19

## 上面版本号中，如果第2位数字有变化，那么代表增加了新的参数，如果只有第3位数字有变化，仅代表更新了注释，没有增加新的参数，可更新可不更新
## 如需更新，请参考WIKI（https://github.com/lan-tianxiang/jd_shell/wiki）中"如何更新配置文件"部分的操作说明，进行智能比对后修改。


################################## 定义Cookie（不填） ##################################
Cookie1="pt_key=xxxxxxxxxx;pt_pin=xxxx;"#不填！！！！

#
##微信金银手指（必填）
export soy_wx_jysz_token=""
export soy_wx_jysz_User_Agent=""
 








